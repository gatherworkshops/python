import tkinter

window = tkinter.Tk()
window.title("Simple Grid")

window.mainloop()